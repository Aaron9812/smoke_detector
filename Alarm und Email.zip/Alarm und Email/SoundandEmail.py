#Bibliotheken importieren
import pygame
import smtplib  

#Variablen impementieren
smoke_indicator = 0
manual_reset = 0

mail_from = 'smarterrauchmelder@gmail.com'
mail_from_password = 'smarterrauchmelder123'
mail_to  = 'duffner.patrick@web.de'
mail_text = 'In Ihrer Wohnung ist ein Feuer ausgebrochen!!!'
mail_subject = 'FEUERALARM!'
mail_data = 'From:%s\nTo:%s\nSubject:%s\n\n%s' % (mail_from, mail_to, mail_subject, mail_text)
server = smtplib.SMTP('smtp.gmail.com:587')

pygame.mixer.init()


#Funktionen

def firealarm():
    pygame.mixer.music.load("Feueralarm.mp3")
    pygame.mixer.music.play(-1) 				#"-1" sorgt für eine Dauerschleife, d.h. das MP3-File wird dauerhaft abgespielt

def sendmail():
	server.starttls()
	server.login(mail_from, mail_from_password)
	server.sendmail(mail_from, mail_to, mail_data)
	print("erfolgreich gesendet!")
	server.quit()

#def lightson():
#Diese Funktion ist für das Lichtanschatlen gedacht, hier Code von Aaron


#Programm

while smoke_indicator == 0:
	print("Alles OK")
	smoke_indicator = int(input("Gebe 0 für 'Alles OK' oder 1 für 'FEUER!!!' ein: ")) # Hier statt manuellen Input, das Signal der Sensoren abfragen

#lightson()
firealarm()
sendmail()


while manual_reset == 0: # Alarm läuft solange, bis ein manueller RESET gedrückt wird (ggfs. bei Fehlalarm)
    print("FEUER!")